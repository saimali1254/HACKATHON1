
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

const resultsEl = $("#results");
const statsEl = $("#stats");
const emptyEl = $("#empty");
const yearEl = $("#year");
yearEl.textContent = new Date().getFullYear();

const api = {
  async search(params = {}){
    const qs = new URLSearchParams(params);
    const res = await fetch(`/api/schemes?${qs.toString()}`);
    return res.json();
  }
};

function renderCard(s, idx){
  const tpl = document.querySelector("#card-template");
  const node = tpl.content.cloneNode(true);
  node.querySelector(".name").textContent = s.name;
  node.querySelector(".desc").textContent = s.description;
  node.querySelector(".category").textContent = s.category;
  node.querySelector(".state").textContent = s.state;
  node.querySelector(".ministry").textContent = s.ministry || "—";
  node.querySelector(".benefits").textContent = s.benefits || "—";
  node.querySelector(".eligibility").textContent = s.eligibility || "—";
  node.querySelector(".documents").textContent = s.documents || "—";
  node.querySelector(".mode").textContent = s.mode || "—";
  const link = node.querySelector(".btn.ghost");
  link.href = s.link || "#";
  link.addEventListener("click", (e)=>{
    if (!s.link || s.link === "#") e.preventDefault();
  });
  const art = node.querySelector(".card");
  art.style.animationDelay = `${idx * 40}ms`;
  return node;
}

function setLoading(on){
  resultsEl.classList.toggle("loading", on);
}

async function refresh(){
  setLoading(true);
  const q = $("#q").value.trim();
  const category = $("#category").value;
  const state = $("#state").value;
  const data = await api.search({ q, category, state });
  setLoading(false);

  resultsEl.innerHTML = "";
  if (!data.length){
    statsEl.classList.add("hidden");
    emptyEl.classList.remove("hidden");
    return;
  }
  emptyEl.classList.add("hidden");
  statsEl.classList.remove("hidden");
  statsEl.textContent = `Showing ${data.length} scheme(s)`;

  data.forEach((s, idx) => {
    resultsEl.appendChild(renderCard(s, idx));
  });
}

$("#search-form").addEventListener("submit", (e) => {
  e.preventDefault();
  refresh();
});

// quick chips
$("#quick-chips").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-q]");
  if (!btn) return;
  $("#q").value = btn.dataset.q;
  refresh();
});

// Initial load
refresh();
