import express from "express";
import cors from "cors";
import morgan from "morgan";
import fs from "fs";
import path from "path";
import fetch from "node-fetch";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(morgan("dev"));

app.use(express.static(path.join(__dirname, "public")));

// --- Data source layer -------------------------------------------------------
// You can switch between 'local' and 'apisetu' by setting DATA_SOURCE env var.
const DATA_SOURCE = process.env.DATA_SOURCE || "local";
const SCHEMES_FILE = path.join(__dirname, "data", "schemes.json");

// Helper: normalize strings
const norm = (s) => (s || "").toString().toLowerCase().trim();

// Build a filter function based on query params
function makeFilter({ q, category, state, ministry, eligibility, mode }) {
  const tokens = norm(q).split(/\s+/).filter(Boolean);
  const categorySet = new Set((category || "").split(",").filter(Boolean).map(norm));
  const stateSet = new Set((state || "").split(",").filter(Boolean).map(norm));
  const ministrySet = new Set((ministry || "").split(",").filter(Boolean).map(norm));
  const eligibilityTokens = new Set((eligibility || "").split(",").filter(Boolean).map(norm));
  const modeSet = new Set((mode || "").split(",").filter(Boolean).map(norm));

  return (s) => {
    // full text tokens
    const hay = norm([s.name, s.description, s.benefits, s.eligibility, s.documents, s.category, s.state, s.ministry].join(" "));
    const textOK = tokens.length ? tokens.every(t => hay.includes(t)) : true;

    const catOK = categorySet.size ? categorySet.has(norm(s.category)) : true;
    const stateOK = stateSet.size ? stateSet.has(norm(s.state)) : true;
    const minOK = ministrySet.size ? ministrySet.has(norm(s.ministry)) : true;

    // eligibility matching: if any token matches eligibility field
    const eligOK = eligibilityTokens.size ? [...eligibilityTokens].some(t => norm(s.eligibility).includes(t)) : true;

    const modeOK = modeSet.size ? [...modeSet].some(t => norm(s.mode).includes(t)) : true;

    return textOK && catOK && stateOK && minOK && eligOK && modeOK;
  };
}

// Optional: example integration stub with API Setu / myScheme (requires key)
async function fetchFromExternalAPI(query) {
  // Placeholder demonstrating how you'd call an external API, if you obtain access.
  // Replace URL and headers with real endpoint and keys.
  const endpoint = process.env.MYSCHEME_API_ENDPOINT; // e.g., "https://api.apisetu.gov.in/myscheme/search"
  const apikey = process.env.MYSCHEME_API_KEY;
  if (!endpoint || !apikey) return null;

  const url = new URL(endpoint);
  if (query.q) url.searchParams.set("q", query.q);
  if (query.state) url.searchParams.set("state", query.state);
  if (query.category) url.searchParams.set("category", query.category);

  const res = await fetch(url.toString(), {
    headers: { "x-api-key": apikey, "accept": "application/json" }
  });
  if (!res.ok) throw new Error(`External API error: ${res.status}`);
  const data = await res.json();

  // Map external fields into our internal schema
  return (data.results || []).map((x) => ({
    id: x.id || x.schemeId || crypto.randomUUID(),
    name: x.title || x.name,
    description: x.summary || x.description || "",
    category: x.category || "General",
    state: x.state || (Array.isArray(x.states) ? x.states[0] : "All India"),
    ministry: x.ministry || x.owner || "—",
    benefits: x.benefits || "",
    eligibility: x.eligibility || "",
    documents: x.documents?.join(", ") || "",
    mode: x.mode || x.howToApply || "Online / Offline",
    link: x.link || x.url || x.applyUrl || "#"
  }));
}

// API: Search & filter schemes
app.get("/api/schemes", async (req, res) => {
  try {
    const query = {
      q: req.query.q || "",
      category: req.query.category || "",
      state: req.query.state || "",
      ministry: req.query.ministry || "",
      eligibility: req.query.eligibility || "",
      mode: req.query.mode || ""
    };

    if (DATA_SOURCE === "apisetu") {
      const ext = await fetchFromExternalAPI(query);
      if (ext) {
        const filterFn = makeFilter(query);
        return res.json(ext.filter(filterFn).slice(0, 200));
      }
    }

    // Fallback: local dataset
    const raw = JSON.parse(fs.readFileSync(SCHEMES_FILE, "utf-8"));
    const filterFn = makeFilter(query);
    const results = raw.filter(filterFn);

    // Simple ranking: by match count in name + description
    const qTokens = norm(query.q).split(/\s+/).filter(Boolean);
    const score = (s) => {
      const hay = norm(s.name + " " + s.description);
      return qTokens.reduce((acc,t) => acc + (hay.includes(t) ? 1 : 0), 0) +
             (norm(s.state) === norm(query.state) && query.state ? 0.5 : 0) +
             (norm(s.category) === norm(query.category) && query.category ? 0.5 : 0);
    };

    results.sort((a,b) => score(b) - score(a));
    res.json(results.slice(0, 200));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch schemes" });
  }
});

// Health
app.get("/api/health", (req, res) => res.json({ ok: true, dataSource: DATA_SOURCE }));

// Fallback to index.html for SPA-like routing (optional)
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Civiora server running at http://localhost:${PORT}`);
});
