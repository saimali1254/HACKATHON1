
# Civiora

Discover Government schemes (central & state) by interest, category and location.

## Quick start

```bash
# 1) Extract and enter the folder
cd civiora

# 2) Install
npm install

# 3) Run
npm start
# Open http://localhost:3000
```

## Features
- Beautiful, colorful UI with glassmorphism, gradients, and smooth transitions.
- Search + filters (category, state) with ranked results.
- Node.js + Express backend with pluggable data source:
  - **Local dataset** (default): `data/schemes.json` (easy to extend).
  - **External API** (optional): set `DATA_SOURCE=apisetu` and provide `MYSCHEME_API_ENDPOINT` + `MYSCHEME_API_KEY` in env.
- Production-friendly structure and simple code.

## Configure external API (optional)
If you have access to a government schemes API (e.g., via API Setu / myScheme), set:
```bash
export DATA_SOURCE=apisetu
export MYSCHEME_API_ENDPOINT="https://<actual-endpoint>"
export MYSCHEME_API_KEY="<your-key>"
npm start
```
The server will proxy and normalize results into the Civiora schema.

## Extend the local dataset
Append objects to `data/schemes.json` with the following fields:
```json
{
  "id": "unique-id",
  "name": "Scheme name",
  "description": "One-liner description.",
  "category": "Health | Education | Housing | Agriculture | Women & Child | Skill Development | Entrepreneurship | ...",
  "state": "All India | <State Name>",
  "ministry": "Issuing ministry/department",
  "benefits": "Key benefits",
  "eligibility": "Eligibility summary",
  "documents": "Key documents",
  "mode": "Online / Offline / Bank / ...",
  "link": "https://official-url"
}
```

## Notes
- This project is for educational/demo use. For production, verify official scheme details and links, and obtain proper API access and permissions.
- You can deploy on services like Render, Railway, or Vercel (Node server).

— Built with ❤️
